const userModel = require("../models/userModel");

exports.getUsers = (req, res) => res.json(userModel.getAll());
exports.getUserById = (req, res) => {
  const user = userModel.getById(req.params.id);
  user ? res.json(user) : res.status(404).json({ message: "Usuário não encontrado" });
};
exports.createUser = (req, res) => {
  userModel.create(req.body);
  res.status(201).json({ message: "Usuário criado com sucesso" });
};
exports.updateUser = (req, res) => {
  userModel.update(req.params.id, req.body);
  res.json({ message: "Usuário atualizado" });
};
exports.deleteUser = (req, res) => {
  userModel.delete(req.params.id);
  res.json({ message: "Usuário removido" });
};
