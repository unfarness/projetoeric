const planModel = require("../models/planModel");

exports.getPlans = (req, res) => res.json(planModel.getAll());
exports.getPlanById = (req, res) => {
  const plan = planModel.getById(req.params.id);
  plan ? res.json(plan) : res.status(404).json({ message: "Plano não encontrado" });
};
exports.createPlan = (req, res) => {
  planModel.create(req.body);
  res.status(201).json({ message: "Plano criado com sucesso" });
};
exports.updatePlan = (req, res) => {
  planModel.update(req.params.id, req.body);
  res.json({ message: "Plano atualizado" });
};
exports.deletePlan = (req, res) => {
  planModel.delete(req.params.id);
  res.json({ message: "Plano removido" });
};
