const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();


app.use(express.json());


app.use(express.static(path.join(__dirname, 'public')));


app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


const dbFile = path.join(__dirname, 'db.json');

if (!fs.existsSync(dbFile)) {
    fs.writeFileSync(dbFile, JSON.stringify({ usuarios: [], produtos: [] }, null, 2));
}


const readDB = () => {
    try {
        return JSON.parse(fs.readFileSync(dbFile, 'utf8'));
    } catch (error) {
        console.error("Erro ao ler o banco de dados:", error);
        return { usuarios: [], produtos: [] };
    }
};

const writeDB = (data) => fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));

//Usuários
app.get('/usuarios', (req, res) => {
    res.json(readDB().usuarios);
});

app.post('/usuarios', (req, res) => {
    const db = readDB();
    const { email, senha } = req.body;
    if (!email || !senha) {
        return res.status(400).json({ mensagem: 'Email e senha são obrigatórios' });
    }
    if (db.usuarios.some(u => u.email === email)) {
        return res.status(400).json({ mensagem: 'Email já cadastrado' });
    }
    const novoUsuario = { id: Date.now(), email, senha };
    db.usuarios.push(novoUsuario);
    writeDB(db);
    res.status(201).json(novoUsuario);
});

app.put('/usuarios/:id', (req, res) => {
    const db = readDB();
    const usuarioIndex = db.usuarios.findIndex(u => u.id == req.params.id);
    if (usuarioIndex === -1) return res.status(404).send('Usuário não encontrado');
    db.usuarios[usuarioIndex] = { ...db.usuarios[usuarioIndex], ...req.body };
    writeDB(db);
    res.json(db.usuarios[usuarioIndex]);
});

//login
app.post('/login', (req, res) => {
    const { email, senha } = req.body;
    if (!email || !senha) {
        return res.status(400).json({ mensagem: 'Email e senha são obrigatórios' });
    }
    const db = readDB();
    const usuario = db.usuarios.find(u => u.email === email && u.senha === senha);
    if (!usuario) {
        return res.status(401).json({ mensagem: 'Email ou senha incorretos' });
    }
    res.json({ mensagem: 'Login bem-sucedido', usuario });
});


app.get('/produtos', (req, res) => {
    res.json(readDB().produtos);
});

app.post('/produtos', (req, res) => {
    const db = readDB();
    const novoProduto = { id: Date.now(), ...req.body };
    db.produtos.push(novoProduto);
    writeDB(db);
    res.status(201).json(novoProduto);
});

app.put('/produtos/:id', (req, res) => {
    const db = readDB();
    const produtoIndex = db.produtos.findIndex(p => p.id == req.params.id);
    if (produtoIndex === -1) return res.status(404).send('Produto não encontrado');
    db.produtos[produtoIndex] = { ...db.produtos[produtoIndex], ...req.body };
    writeDB(db);
    res.json(db.produtos[produtoIndex]);
});

app.delete('/produtos/:id', (req, res) => {
    const db = readDB();
    db.produtos = db.produtos.filter(p => p.id != req.params.id);
    writeDB(db);
    res.sendStatus(204);
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
