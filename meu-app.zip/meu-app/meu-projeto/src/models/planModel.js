let plans = [];

module.exports = {
  getAll: () => plans,
  getById: (id) => plans.find((p) => p.id === id),
  create: (plan) => plans.push(plan),
  update: (id, newData) => {
    const index = plans.findIndex((p) => p.id === id);
    if (index !== -1) plans[index] = { ...plans[index], ...newData };
  },
  delete: (id) => {
    plans = plans.filter((p) => p.id !== id);
  },
};
