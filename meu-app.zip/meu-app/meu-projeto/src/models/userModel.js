let users = [];

module.exports = {
  getAll: () => users,
  getById: (id) => users.find((u) => u.id === id),
  create: (user) => users.push(user),
  update: (id, newData) => {
    const index = users.findIndex((u) => u.id === id);
    if (index !== -1) users[index] = { ...users[index], ...newData };
  },
  delete: (id) => {
    users = users.filter((u) => u.id !== id);
  },
};
